
# Configuração

Com o comando inicial $git config --list consegui analisar que as minhas configurações estavam corretas


  

# Criação do repositório

Nesta fase tive alguns problemas na alinea d). Não conseguia adicionar o codigo realizado na aula anterior ao repositório por isso acabei por dar setup ao reposiório de uma forma diferente que a pedida. Através de git clone {URL} consegui clonar o repositório e adicionar os ficheiros necessários.








